<?php
require('Cmahasiswa.php');
$mhs = new CMahasiswa();
$mhs->cetakListMhs();
