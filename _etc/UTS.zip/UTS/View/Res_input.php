<html>
<head>
<title>Input Menu</title>
</head>
<?php

echo $data;

?>
</body>
</html>
