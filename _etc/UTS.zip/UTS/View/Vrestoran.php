<html>
<head>
<title>Daftar Menu</title>
</head>
<?php

echo $data;
?>
</body>
</html>
