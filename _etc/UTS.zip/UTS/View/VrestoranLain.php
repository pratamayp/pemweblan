<html>
<head>
<title>Daftar Menu Lainnya</title>
</head>
<?php

echo $data;
?>
</body>
</html>
