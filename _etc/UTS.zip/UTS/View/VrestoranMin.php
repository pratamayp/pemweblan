<html>
<head>
<title>Daftar Menu Minuman</title>
</head>
<?php

echo $data;
?>
</body>
</html>
