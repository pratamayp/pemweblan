<html>
<head>
<title>Edit Menu</title>
</head>
<?php

echo $data;
?>
</body>
</html>
