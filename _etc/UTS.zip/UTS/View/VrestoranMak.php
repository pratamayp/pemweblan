<html>
<head>
<title>Daftar Menu Makanan</title>
</head>
<?php

echo $data;
?>
</body>
</html>
