<html>
<head>
<title>Detail Menu</title>
</head>
<?php

echo $data;
?>
</body>
</html>
