<?php
error_reporting(0);
include_once('./Model/Mahasiswa_Model.php');
	class Mahasiswa_Controller{

	 
        var $nim;
	    var $nama;
	    var $kelas;
        var $alamat;
        var $angkatan;

		public function __construct(
            $nama       		='belumtahu',
            $nim 				='M3118001',
            $kelas				='TI A',
            $alamat 			='Surakarta',
            $angkatan           ='2018'
            ){
                $this->nama        		    =$nama;
                $this->nim					=$nim;
                $this->kelas				=$kelas;
                $this->angkatan        		=$angkatan;                           
                $this->alamat 				=$alamat;
		}

		
		public function TabelMahasiswa(){
			 	$modelmahasiswa   = new Mahasiswa_Model();
		        $query_list 	= $modelmahasiswa->getAll(); 
				$data='              
		            <h3> TABEL DATA MAHASISWA </h3>
		                <table width="500" border="1" cellpadding="2" cellspacing="2
		                ">
		                <tr>
		                    <td><center>No</td> 
							<td><center>NIM</td>
							<td><center>Nama Mahasiswa</td>
                            <td><center>Kelas</td>
                            <td><center>Angkatan</td>
		                    <td><center>Alamat</td>
		                    
		                    <td><center>Aksi</td>
		                </tr> 
					';
		               
		       
		        while($row 	= mysqli_fetch_array($query_list)){
				$data.='<tr><td>'.$row['id'].  '</td>
                <td>'.$row['nim'].  '</td>
                <td>'.$row['nama'].  '</td>
                <td>'.$row['kelas'].  '</td>
                <td>'.$row['angkatan'].  '</td>
                <td>'.$row['alamat']. '</td>
				        	 

				        	 <td><a href="Detail.php?id='.$row['id'].'">
				        	 	 <input type="button" name="detail" value="DETAIL" /></a>

				        	 <a href="Hapus.php?id='.$row['id'].'">
				        	 <input type="button" name="hapus" value="HAPUS" /></a>


				        	  <a href="index.php?target=edit&id='.$row['id'].'">
				        	 	 <input type="button" name="edit" value="Update" /></a>
	 
				        	 </td>

				         </tr>';
				}
				$data.="</table>";	          
				$this->loadView('./View/ListMahasiswa.php', $data);

		}

		public function InputMahasiswa(){

			if(!isset($_POST['tombol'])){
				require ('./View/TambahMahasiswa.php');
				
		     }else{
		     	
                 $this->nim 				= $_POST['nim'];
                 $this->nama         	    = $_POST['nama'];
                 $this->kelas		 	    = $_POST['kelas'];
                 $this->angkatan		 	= $_POST['angkatan'];
                 $this->alamat 			    = $_POST['alamat'];						

			     	$modelmahasiswa = new Mahasiswa_Model();
			     	$modelmahasiswa->InsertMahasiswa($this);
			     	$this->TabelMahasiswa();	
		     }
		}
		public function loadView($file, $data){
			require($file);
		}

		public function DeleteDataMahasiswa($id) 
		{
			$modelmahasiswa  = new Mahasiswa_Model();
			$modelmahasiswa->DeleteDataMahasiswa($id);
		}

		public function Detail($id){
		 	$modelmahasiswa = new Mahasiswa_Model();
		 	$query = $modelmahasiswa->Aksi_Detail($id);
		 	$row = mysqli_fetch_array($query);

		 	$tabel= '<center>
			<h3>TABEL DETAIL DATA MAHASISWA</h3>
			<table width="400px" border="1">
			
            <tr>
                <td>NIM</td>
                <td>:</td>
                <td>'.$row['nim'].'</td>
            </tr>
			<tr>
				<td>Nama Mahasiswa</td>
				<td>:</td>
				<td>'.$row['nama_peserta'].'</td>
			</tr>
			<tr>
				<td>Kelas</td>
				<td>:</td>
				<td>'.$row['kelas'].'</td>
            </tr>
            <tr>
				<td>Angkatan</td>
				<td>:</td>
				<td>'.$row['angkatan'].'</td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td>'.$row['alamat'].'</td>
			</tr>
			</table></center>';

			$this->id=$id;
			require ('./View/DetailMahasiswa.php');
		}

		function UpdateMahasiswa()
	 	{	
	 			$modelmahasiswa = new Mahasiswa_Model();
				$query 			= $modelmahasiswa->getID();
				$id 			= $modelmahasiswa->getIDMahasiswa();		
			if(!isset($_POST['update']))
			{
				include('./View/EditMahasiswa.php');
			}else
			{
				
				$this->nim 			 	= $_POST['nim'];				
				$this->nama_peserta 	= $_POST['nama'];
                $this->kelas		 	= $_POST['kelas'];
                $this->angkatan		 	= $_POST['angkatan'];	
				$this->alamat 			= $_POST['alamat'];								
 
				$modelmahasiswa 		= new Mahasiswa_Model();
			    $modelmahasiswa->getUpdate($this,$id);
			    $this->TabelSeminar();
			}
	 	}



		

	}
?>