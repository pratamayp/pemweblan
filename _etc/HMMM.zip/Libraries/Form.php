<?php 
class Form{ 
	var $fields    = array(); 
	var $action;
	var $submit   = "";
	var $jumField = 0;

	
	function __construct($action, $submit){ //Mengguna construct
		$this->action = $action;
		$this->submit = $submit;
	}
	function displayForm(){
		echo "<form action='".$this->action."' method='post'>"; 
		echo "<table width='90%'>";
		//echo "<table widht='100%'>"; 
			for($i=0;$i<$this->jumField;$i++){
				if($this->fields[$i]['type'] == 'textarea'){
					echo "<tr>
						  <td align ='right'>".$this->fields[$i]['label']."</td>";
					echo "<td>
					      <textarea name='".$this->fields[$i]['name']."'></textarea>
					      </td>
					      </tr>";
				}else if($this->fields[$i]['type'] == 'select'){
					echo "<tr>
					      <td align = 'right'>".$this->fields[$i]['label']."</td>";
					echo "<td>
						  <select name='".$this->fields[$i]['name']."'>";
						  foreach ($this->fields[$i]['value'] as $value) {
						  		echo "<option value='".$value['value']."'>".$value['text']."</option>";
						  }
					echo "</select>
						  </td>
						  </tr>";
				}
				else if($this->fields[$i]['type']=='radio')
				{
					echo "<tr><td>".$this->fields[$i]['label']."</td>";
				echo "<td><input type='radio' name='".$this->fields[$i]['name']."'";
				if(!empty($this->fields[$i]['option'])){
					foreach($this->fields[$i]['option'] as $atribute => $nilai){
						echo $atribute."='".$nilai."'";
					}
				}
				echo "value='".$this->fields[$i]['value']."'></td></tr>";
				}
				elseif ($this->fields[$i]['type']=='checkbox')
				{
					echo"<tr><td align='right'>".$this->fields[$i]['label']."</td>";
					foreach ($this->fields[$i]['option'] as $option => $val)
						if ($this->fields[$i]['value'] = $option){
							echo "<td><input type='checkbox' value='".$option."' name='".$this->fields[$i]['name']."'>";
							echo "$val</td></input>";
						} else {
							echo "<td><input type='checkbox' value='".$option."' name='".$this->fields[$i]['name']."'>";
							echo "$val</td></input>";
						}
					echo"</tr>";
				}
				elseif ($this->fields[$i]['type']=='date')
				{
					echo"<tr><td align='right'>".$this->fields[$i]['label']."</td>";
					echo"<td><input type='date' name='".$this->fields[$i]['name']."' value='".$this->fields[$i]['value']."'></td></tr>";
				}
					 
				else{
					echo "<tr>
						  <td align = 'right'>".$this->fields[$i]['label']."</td>";
					echo "<td>
					      <input type = '".$this->fields[$i]['type']."'
					             name = '".$this->fields[$i]['name']."'";
					      if(!empty($this->fields[$i]['option'])){
					      	foreach ($this->fields[$i]['option'] as $atribute => $nilai) {
					      		echo $atribute."='".$nilai."'";
					      	}
					      }
					echo "value='".$this->fields[$i]['value']."'>
					</td>
					</tr>";
				}
			}
			echo "<tr>
				  <td>
				  <td><input type='submit' name='tombol' value = '".$this->submit."'></td></tr>";
				  echo "</table>";
				  echo "</form>";
				  echo "</center>";
	}

	function displayFormEdit(){
		echo "<form action='".$this->action."' method='post'>"; 
		echo "<table width='90%'>";
		//echo "<table widht='100%'>"; 
			for($i=0;$i<$this->jumField;$i++){
				if($this->fields[$i]['type'] == 'textarea'){
					echo "<tr>
						  <td align ='right'>".$this->fields[$i]['label']."</td>";
					echo "<td>
					      <textarea name='".$this->fields[$i]['name']."'></textarea>
					      </td>
					      </tr>";
				}else if($this->fields[$i]['type'] == 'select'){
					echo "<tr>
					      <td align = 'right'>".$this->fields[$i]['label']."</td>";
					echo "<td>
						  <select name='".$this->fields[$i]['name']."'>";
						  foreach ($this->fields[$i]['value'] as $value) {
						  		echo "<option value='".$value['value']."'>".$value['text']."</option>";
						  }
					echo "</select>
						  </td>
						  </tr>";
				}
				else if($this->fields[$i]['type']=='radio')
				{
					echo "<tr><td>".$this->fields[$i]['label']."</td>";
				echo "<td><input type='radio' name='".$this->fields[$i]['name']."'";
				if(!empty($this->fields[$i]['option'])){
					foreach($this->fields[$i]['option'] as $atribute => $nilai){
						echo $atribute."='".$nilai."'";
					}
				}
				echo "value='".$this->fields[$i]['value']."'></td></tr>";
				}
				elseif ($this->fields[$i]['type']=='checkbox')
				{
					echo"<tr><td align='right'>".$this->fields[$i]['label']."</td>";
					foreach ($this->fields[$i]['option'] as $option => $val)
						if ($this->fields[$i]['value'] = $option){
							echo "<td><input type='checkbox' value='".$option."' name='".$this->fields[$i]['name']."'>";
							echo "$val</td></input>";
						} else {
							echo "<td><input type='checkbox' value='".$option."' name='".$this->fields[$i]['name']."'>";
							echo "$val</td></input>";
						}
					echo"</tr>";
				}
				elseif ($this->fields[$i]['type']=='date')
				{
					echo"<tr><td align='right'>".$this->fields[$i]['label']."</td>";
					echo"<td><input type='date' name='".$this->fields[$i]['name']."' value='".$this->fields[$i]['value']."'></td></tr>";
				}
					 
				else{
					echo "<tr>
						  <td align = 'right'>".$this->fields[$i]['label']."</td>";
					echo "<td>
					      <input type = '".$this->fields[$i]['type']."'
					             name = '".$this->fields[$i]['name']."'";
					      if(!empty($this->fields[$i]['option'])){
					      	foreach ($this->fields[$i]['option'] as $atribute => $nilai) {
					      		echo $atribute."='".$nilai."'";
					      	}
					      }
					echo "value='".$this->fields[$i]['value']."'>
					</td>
					</tr>";
				}
			}
			echo "<tr> 
				  <td>
				  <td><input type='submit' name='update' value = '".$this->submit."'></td></tr>";
				  echo "</table>";
				  echo "</form>";
				  echo "</center>";
	} 
 
	function addField($name,$label, $type = 'text', $value = '', $option = array()){ 
	 	$this->fields[$this->jumField]['name']  = $name; 
	 	$this->fields[$this->jumField]['label'] = $label; 
	 	$this->fields[$this->jumField]['type']  = $type; 
	 	$this->fields[$this->jumField]['value'] = $value; 
	 	$this->fields[$this->jumField]['option']= $option; 
	 	$this->jumField++; 
	} 
	function addFieldDate($name,$label, $type = 'date', $value = ''){ 
	 	$this->fields[$this->jumField]['name']  = $name; 
	 	$this->fields[$this->jumField]['label'] = $label; 
	 	$this->fields[$this->jumField]['type']  = $type; 
	 	$this->fields[$this->jumField]['value'] = $value; 
	 	$this->jumField++; 
	} 
	/*function addTextArea($name,$label, $value = '', $type = 'textarea'){ 
	 	$this->fields[$this->jumField]['name']  = $name; 
	 	$this->fields[$this->jumField]['label'] = $label; 
	 	
	 	$this->fields[$this->jumField]['value'] = $value;
	 	$this->fields[$this->jumField]['type']  = $type;  
	 	$this->jumField++; 
	} */

	function addRadio($name,$label,$value='',$option=array()){
		 $this->fields[$this->jumField]['type']="radio";
		 $this->fields[$this->jumField]['name']=$name;
		 $this->fields[$this->jumField]['label']=$label;
		 $this->fields[$this->jumField]['value']=$value;
		 $this->fields[$this->jumField]['option']=$option;
		 $this->jumField++;
	}

	function addTextArea($name,$label,$type='textarea', $value=''){ 
	 	$this->fields[$this->jumField]['name']  = $name; 
	 	$this->fields[$this->jumField]['label'] = $label; 
	 	$this->fields[$this->jumField]['type']  = $type;  
		$this->fields[$this->jumField]['value']=$value;
	 	$this->jumField++; 
	} 

	function addSelect($name,$label,$type = 'select', $value = array()){ 
	 	$this->fields[$this->jumField]['name']  = $name; 
	 	$this->fields[$this->jumField]['label'] = $label; 
		$this->fields[$this->jumField]['type']  = $type; 
	 	$this->fields[$this->jumField]['value'] = $value; 
	 	$this->jumField++; 
	}

	function addFieldCheckBox($name,$label,$value,$option=array()){
		 $this->fields[$this->jumField]['type']="checkbox";
		 $this->fields[$this->jumField]['name']=$name;
		 $this->fields[$this->jumField]['label']=$label;
		 $this->fields[$this->jumField]['value']=$value;
		 $this->fields[$this->jumField]['option']=$option;
		 $this->jumField++;
	}

	function terimaForm(){
		for($i=0; $i<$this->jumField;$i++){
			$this->fields[$i]['value'] = $_POST[$this->fields[$i]['name']]; 
		}
	}

	function cetakForm(){
		for($i=0; $i<$this->jumField;$i++){
			echo $this->fields[$i]['label']." : ".$this->fields[$i]['value']."</br>";
		}
	}
} 
?>