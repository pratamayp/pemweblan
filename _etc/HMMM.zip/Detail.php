<?php
	include('Controller/Mahasiswa_Controller.php');
	$mahasiswa = new Mahasiswa_Controller();
	$id = $_GET['id'];
	$mahasiswa->Detail($id);
?>