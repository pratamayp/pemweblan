<?php
	include ("./Controller/Mahasiswa_Controller.php");
	$mahasiswa = new Mahasiswa_Controller();
?>
	<h2>Data Mahasiswa</h2>
		<?php
			$id = $_GET['id'];
			$mahasiswa->DeleteDataMahasiswa($id);
		?> 