<!DOCTYPE html>
<?php	
?>
<html>
<head>
	<title> List Data Mahasiswa </title>
</head>
	<body bgcolor='lightgray'>
		<h3>TABEL INPUT DATA MAHASISWA</h3>
		<?php
		
	 	$form = new Form ("","Input Mahasiswa");

		
         $form->addfield('nim', 'NIM','text',"",array('required' => 'required'));
         $form->addField('nama','Nama','text',"",array('required' => 'required'));
         $form->addfield('kelas', 'Kelas','text',$sql['kelas'],array('required' => 'required'));
         $form->addfield('angkatan', 'Angkatan','text',$sql['angkatan'],array('required' => 'required'));
		 $form->addField('alamat','Alamat','text',"",array('required' => 'required'));		
		// $form->addField('keaktifan','','hidden','Aktif');
		$form->displayForm();

		?>
	</body>
</html>