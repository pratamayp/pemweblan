<!DOCTYPE html>
<html>
<head>
	<title>TAMPILAN DATA MAHASISWA</title>
</head>
<body bgcolor="lightblue">
	<?php
		echo $data;
	?>

</body>
</html>