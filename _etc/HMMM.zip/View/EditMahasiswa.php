<!DOCTYPE html>
<?php	
?>
<html>
<head>
	<title> TAMPILAN EDIT DATA MAHASISWA </title>
</head>
	<body bgcolor='lightgray'>
		<h3>TABEL UPDATE DATA MAHASIWA</h3>
		<?php
		$this->id=$_GET['id'];
		$modelmahasiswa = new Mahasiswa_Model();
		$hasil 			= $modelmahasiswa->Aksi_Detail($this->id);
		$form 			= new Form("","Edit");

		while($sql = mysqli_fetch_array($hasil)){		
	 		
			$form->addfield('nim', 'NIM','text',$sql['nim'],array('required' => 'required'));	
			$form->addField("nama","Nama","text",$sql['nama'],array('required' => 'required'));
            $form->addfield('kelas', 'Kelas','text',$sql['kelas'],array('required' => 'required'));
            $form->addfield('angkatan', 'Angkatan','text',$sql['angkatan'],array('required' => 'required'));
			$form->addTextArea("alamat","Alamat",'',$sql['alamat']);			
			$form->displayFormEdit();
		}
		?>
	</body>
</html>