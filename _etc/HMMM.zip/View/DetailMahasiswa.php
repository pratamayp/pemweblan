<!DOCTYPE html>
<html>
<head>
	<title>TAMPILAN DETAIL MAHASISWA</title>
</head>
<body bgcolor="lightblue">
	<?php
	echo $tabel;
?>
	<p></p>
	<center><a href='./index.php'><button> Kembali</button></a></center>	

</body>
</html>