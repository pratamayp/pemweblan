<?php
class Mahasiswa_Model{
		
		var $host		= "localhost";
		var $user		= "root";
		var $pass		= "";
		var $db			= "mahasiswabaru";
		
		public function koneksidb(){
			return $koneksi	= mysqli_connect($this->host, $this->user, $this->pass, $this->db);
		}
	
		public function getAll(){
			$koneksi    = $this->koneksidb();
			$query      = "SELECT * FROM mahasiswa";
			$query_list = mysqli_query($koneksi,$query);
			return $query_list;
		}
	
		public function InsertMahasiswa($data){
				$koneksi    = $this->koneksidb();
				$sql 		= "INSERT INTO mahasiswa(nim,nama,kelas,angkatan,alamat) 
								values ('".$data->nim."',
                                '".$data->nama."',
								'".$data->kelas."',								
								'".$data->angkatan."',
								'".$data->alamat."')";

				// mysqli_query($koneksi, $sql);
				$query_list	= mysqli_query($koneksi, $sql);
				return $query_list;

		}
		public function DeleteDataMahasiswa($id){
			$koneksi    = $this->koneksidb();
			$query 		="DELETE FROM mahasiswa WHERE id = '$id'";
			$query_list = mysqli_query($koneksi, $query);
			echo "<script>window.alert('Data Sukses Di HAPUS');window.location=('index.php')</script>";
			return $query_list;
		}

		public function Aksi_Detail($id)
	 	{
		 	$koneksi=$this->koneksidb();
		 	$hasil = mysqli_query($koneksi, "SELECT * FROM mahasiswa WHERE id='$id'");
		 	return $hasil;
	 	}

	 	public function getUpdate($row,$id)
	 	{

	 	$koneksi=$this->koneksidb();
	 	$sql=mysqli_query($koneksi, "UPDATE mahasiswa 
	 				SET nim				='".$row->nim."',
                        nama        	='".$row->nama."',
					 	kelas			='".$row->kelas."', 	 					
                        angkatan	    ='".$row->angkatan."',
	 					alamat 			='".$row->alamat."'	 					
	 					WHERE id='".$id."'");

	 	mysqli_query($koneksi, $sql);
				$query_list	= mysqli_query($koneksi, $sql);
				return $query_list;
	 	}

	 	public function getID()
		{
			
			$koneksi= $this->koneksidb();
			$id 	= $_GET['id']; 
			$query 	= "SELECT * FROM mahasiswa WHERE id='$id'";
			$row 	= mysqli_fetch_array(mysqli_query($query_con,$query));
			return $row;
		}
		
		public function getIDMahasiswa()
		{
			$koneksi=$this->koneksidb();
			$id=$_GET['id']; 
			return $id;
		}
		}
?>