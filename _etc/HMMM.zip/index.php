<?php
	include('Controller/Mahasiswa_Controller.php');
	include('Libraries/Form.php');

		$mahasiswa= new Mahasiswa_Controller();

		echo "<a href='index.php'>Home</a>| | "; 
		echo "<a href='index.php?target=input'>Input Data Mahasiswa</a></br>";

			if(!isset($_GET['target'])){
				$mahasiswa->TabelMahasiswa();	
			}else
			if ($_GET['target']=='input') {
				$mahasiswa->InputMahasiswa();
			}
			else
			if($_GET['target']=='hapus'){
				$mahasiswa->DeleteDataMahasiswa();
			}
			else
			if($_GET['target']=='edit'){
				$mahasiswa->UpdateMahasiswa();
		}
?>