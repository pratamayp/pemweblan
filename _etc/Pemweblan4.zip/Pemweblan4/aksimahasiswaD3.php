<?php
require ('MahasiswaD3.php');

    $mhs1 = new MahasiswaD3;
    $mhs1->isiData("M3123456","Potato Chips",2000, "SV", "IOT");//membuat objek
    //$mhs1 =$umur = $mhs1->hitungUmur();
    $mhs2 = new MahasiswaD3();
    $mhs2->isiData("M3198765","Choco Chips",2000);
    //$mhs2 =$umur = $mhs2->hitungUmur();
    $mhs2->dataKelulusan("Dinas Kesehatan Solo", "Aplikasi Cari Dokter");

    $mhs1->cetakData();
    $mhs2->cetakData();
?>