<?php
require ('form.php');

    $formMhs = new Form("", "Input Mahasiswa");
    $formMhs-> addField("nim","NIM Mahasiswa");
    $formMhs-> addField("nama","Nama Mahasiswa");
    $formMhs-> addField("tahun","Tahun Lahir");
    $formMhs-> addField("nohp","Nomor Handphone");
    if(isset($_POST['tombol'])){
        $formMhs->getForm();//input data
        $formMhs->cetakForm();//cetak data
    }else{
        $formMhs->displayForm();//tampil form
    }
    
?>