<?php
require ('mahasiswa.php');
$mhs=new Mahasiswa();
$mhs->inputForm();
?>