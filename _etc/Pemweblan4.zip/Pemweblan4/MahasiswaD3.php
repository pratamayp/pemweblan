<?php
require('mahasiswa.php');

class MahasiswaD3 extends mahasiswa {
    protected $instansiMagang;
    protected $judulTA;
    

    public function __construct($nim="M3XXXXXX",$nama="anonim",$tahun=0,
            $instansi="SV", $judul="Belum Ada Judul")//override
    {
        parent :: __construct($nim, $nama, $tahun);
        $this->instansiMagang = $instansi;
        $this->judulTA = $judul;

    }
    public function dataKelulusan($instansi, $judul)
    {

        $this->instansiMagang = $instansi;
        $this->judulTA = $judul;
    }
    public function cetakData()//override
    {
        //echo "----------------------------------------"."</br>";
        //echo "Nim Mahasiswa ".$this->nim."</br>";
        //echo "Nama Mahasiswa ".$this->nama."</br>";
        //echo "Tahun Lahir ".$this->tahunlahir."</br>";
        //echo "Umur Sekarang  ".$this->umur."</br>";
        Mahasiswa :: cetakData();
        echo "Instansi Magang ".$this->instansiMagang."</br>";
        echo "Judul Tugas Akhir  ".$this->judulTA."</br>";
        echo "----------------------------------------</br>";
        echo "----------------------------------------</br>";
    }
    public function hitungUmur()
    {
        $hasil=date('Y')-($this->tahunlahir);
        return $hasil;
    }

} //end class

?>