<?php
require ('mahasiswa.php');

    $mhs1 = new Mahasiswa("M3119080","Salsha Ristania",2000);//membuat objek
    //$mhs1->isiData("M3119080","Salsha Ristania",2000);
    //$mhs1 =$umur = $mhs1->hitungUmur();
    $mhs2 = new Mahasiswa();
    $mhs2->isiData("M3119070","Salsabila Fithriyah",2000);
    //$mhs2 =$umur = $mhs2->hitungUmur();

    $mhs1->cetakData();
    $mhs2->cetakData();
?>